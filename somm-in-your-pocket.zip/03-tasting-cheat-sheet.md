# Tasting Cheat Sheet

_Upload this to the Project's files. The agent will reference it. You can also keep it in your phone for the moment the bottle arrives._

---

## When the sommelier brings the bottle

1. They show you the label. Confirm it is the wine you ordered. ("Yes, that is it.")
2. They open it, hand you the cork. You do not need to sniff it. Just check it is intact, not crumbly, not wet through. Set it down.
3. They pour a small splash in your glass. This is your tasting pour. Take your time.

## The three checks

### Look
- Hold the glass against something white (napkin, tablecloth).
- Reds should be ruby to garnet to deep purple, depending on style. A young Barolo is brick-red, not opaque. A Napa Cab is closer to ink.
- Whites should be pale straw to gold. If a white looks brown, it is oxidized. Say so.

### Smell
- Swirl once, then sniff. You are not auditioning. You are checking that the wine smells like itself.
- Should smell like fruit, earth, flowers, spice, depending on the wine. Should NOT smell like:
  - Wet cardboard or basement = cork taint (TCA). Send back.
  - Vinegar or nail polish = volatile acidity, off. Send back.
  - Nothing at all = the wine is "closed," might need decanting. Ask for a few minutes.

### First sip
- Small sip. Let it cover your tongue.
- You are checking four things:
  - **Acid.** Does it make your mouth water? Good wines do. Flat wines feel dead.
  - **Fruit.** Is there fruit character, or does it taste muted?
  - **Tannin** (reds only). Does it grip the sides of your tongue? Good. Does it dry out your whole mouth violently? Maybe needs food or air.
  - **Finish.** Does the flavor linger after you swallow? Long finish = good wine.

## When to say yes

If it looks right, smells right, and the first sip is alive, say yes. Most wines you order are fine. The tasting pour is not a chance to be picky, it is a chance to catch the rare flawed bottle.

Phrase to use: "Wonderful, thank you."

## When to say something

- Cork taint (wet cardboard smell): "I think this might be corked. Could you taste it?"
- Oxidized (smells flat, fruit feels muted, brownish color): "This feels oxidized. Could you taste it?"
- Wildly different from what you expected: "This is much [bigger / lighter / sweeter] than I was expecting. Could you taste it?"

The sommelier will taste it. If you are right, they replace it. If you are wrong, you learn something.

## Temperature

- **Whites:** 45-55°F. Most restaurants pour them too cold. If your white is so cold you cannot taste anything, let it sit in the glass for five minutes.
- **Reds:** 60-65°F. Most restaurants pour them too warm. If your red feels heavy and hot, ask for an ice bucket for 10 minutes. Yes, you can chill a red.
- **Sparkling:** 40-45°F. Cold.

## Glass

- Use the glass the sommelier brings. If you are at home, give reds a wide bowl, whites a narrower one. Stop holding by the bowl. Hold by the stem so your hand does not warm the wine.
