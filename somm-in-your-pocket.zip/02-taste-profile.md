# My Wine Taste Profile

Fill this in before you drop it in your Claude Project.
Be specific. The more honest, the better your Somm picks.

---

## Wines I love

Grape, region, vibe. Producer if you have one.

- [e.g., Barolo. Nebbiolo, age-able, structured.]
- [e.g., Chablis. Crisp, mineral, no oak.]
- [e.g., Sancerre. Sauv blanc with stones in it.]
- [Add your own]
- [Add your own]

## Wines I refuse

The grapes, styles, or flavors I will not drink. Be ruthless.

- [e.g., Buttery Chardonnay. No oak, no diacetyl.]
- [e.g., Sweet Riesling.]
- [Add your own]

## Non-negotiables

The things that have to be there, regardless of style.

- [e.g., Acid is non-negotiable. Flabby is out.]
- [e.g., Story over score. Producer over rating.]
- [Add your own]

## Price tiers

Be honest with yourself.

- Weeknight pour: $[X]
- Date night: $[X]
- Splurge / birthday: $[X]

## Anything else

Allergies, regions you're curious about, wines you want to learn, dealbreakers your Somm should know.

- [Add anything else]
