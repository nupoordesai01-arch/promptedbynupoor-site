# Wine Diary

_Upload this to the Project's files. Starts empty. After each meal, send the agent a quick "log this" message and it will fill in the entry for you. Over time, the agent uses this to make better, more personal picks._

---

## How to log

After dinner, send the agent a single message:

> Log this. We had [wine name] at [restaurant], with [food]. Price was [$]. I [loved / liked / was meh on] it because [one sentence].

The agent will format it and append it to this diary.

---

## Entries

(Empty. Your first entry goes here.)

---

## Format the agent will use

### YYYY-MM-DD, Restaurant Name
- **Wine:** Producer, name, vintage
- **Region / grape:** Where it is from, what grape(s)
- **Food:** What you ate
- **Price:** $X
- **Rating:** Loved / Liked / Meh / Send back
- **Note:** One sentence on why
- **Pattern flag:** What this tells the agent about your taste (e.g., "confirms love of high-acid Loire whites" or "reminder: too tannic for fish")
