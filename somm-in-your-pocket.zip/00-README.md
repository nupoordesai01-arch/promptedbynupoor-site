# A Somm in Your Pocket

Four files. One Claude Project. A wine expert that learns you over time.

---

## What this is

This is the starter kit for building your own personal sommelier inside a Claude Project. You set it up once. Then every time you go out, you paste the wine list in and the Somm gives you:

- 3 picks, ranked, with stories
- A backup if your top pick is 86'd
- 2 questions to ask the actual sommelier at the restaurant
- A tasting prompt for when the bottle arrives

It runs inside Claude. It's private to your account. You can delete it whenever.

---

## How to set it up (20 minutes)

1. **Open Claude.** Go to claude.ai. Click "Projects" in the left sidebar. Click "Create project." Name it Sommelier.

2. **Paste the system prompt.** Open `01-system-prompt.md` in this folder. Copy the entire contents. In your new project, find the "Project instructions" field and paste it in. Save.

3. **Edit your taste profile.** Open `02-taste-profile.md`. Replace every bracketed section with your actual answers. Wines you love. Wines you refuse. Your price tiers. Be honest. The more specific, the better it picks.

4. **Upload all 4 files to the project.** In your Claude Project, find the project files section and upload all four files in this kit (including the diary, even though it's empty).

5. **Test it.** Send your Somm a message: "I'm at a French wine bar tonight, date night budget, eating duck rillettes then steak. Here's the wine list: [paste a sample list]." It should respond with a formatted card.

That's it. Your Somm is live.

---

## How to use it

**Before dinner:**
Paste the wine list, tell it the restaurant, what you're eating, your budget tier, and who you're with. It returns a card.

**At the table:**
Open the card on your phone. Order from it. Ask the real sommelier the two questions. Watch the conversation light up.

**When the bottle arrives:**
Use the tasting prompt to check the first pour. It tells you what to look for in the look, smell, and first sip.

**After dinner:**
Message your Somm: "Log this. We had [wine] at [restaurant] with [food]. It was $X. I [loved / liked / was meh on] it because [one sentence]." Your Somm updates the diary. Over time, it learns you.

---

## A note on privacy

This runs on Anthropic's servers. Anthropic does not train on your project data. Your conversations are not shared. You can delete the project and everything in it whenever you want. That's private, not local.

If you want fully local AI on your laptop, that's a different setup (Ollama, a local LLM, a real engineering project). Not what this kit is.

---

## Built by

Prompted by Nupoor — PMM at WhatsApp, building AI into her life, showing you how to build it into yours.

promptedbynupoor.com
@promptedbynupoor on TikTok

If you build your Somm and have your first dinner with it, tag me. I'll repost the best ones.

xx
Nupoor
